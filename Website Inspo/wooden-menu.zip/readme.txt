
  <!-- ///////////////////////////////////////////////////////// --> 
  <!-- /                                                       / --> 
  <!-- /  Freebies are energized by Breezy                     / --> 
  <!-- /  WWW: http://www.breezyprague.com/freebies            / --> 
  <!-- /  GSM: +420 728 82 32 42 (Czech Republic, Europe)      / --> 
  <!-- /  Email: hello@breezyprague.com                        / --> 
  <!-- /                                                       / --> 
  <!-- ///////////////////////////////////////////////////////// --> 
 

TERMS OF USE:

All resources made available on www.breezyprague.com/freebies, including  web elements and themes are free for use in personal and commercial projects.

Files are freely to use, without any restriction, in software programs, web templates and other materials intended for sale or distribution. No attribution or backlinks are required.

You are not permitted to make the resources found on www.breezyprague.com/freebies available for distribution elsewhere �as is� without prior consent.

Radek Botos
Breezy Prague

